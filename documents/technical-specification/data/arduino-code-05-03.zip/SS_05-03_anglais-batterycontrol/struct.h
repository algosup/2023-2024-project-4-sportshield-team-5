struct myConfig {
  short int pin = 0;
  String Name = "\n";
  bool isActivate = false;
  
};